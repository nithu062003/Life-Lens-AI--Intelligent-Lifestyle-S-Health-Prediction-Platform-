"""
Life Lens AI — Flask backend.
Endpoints: recommend, allergy-check, health-score, calculators, nutrient-lookup, model-info
"""

from flask import Flask, render_template, request, jsonify
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from src.ml_engine import (
    predict_diet, check_allergies, get_safe_alternatives,
    check_food_items, MEAL_PLANS, HEALTH_TIPS, ALLERGY_FOODS,
    load_model, train_model,
    calculate_bmr, calculate_tdee, calculate_water_intake,
    calculate_calories_burned, calculate_health_score,
    get_nutrient_targets, FOOD_NUTRITION_DB
)

app = Flask(__name__)

@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type"
    r.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return r

def _build_patient(data):
    return {
        "Age":                    float(data.get("age", 30)),
        "Gender":                 data.get("gender", "Male"),
        "Weight_kg":              float(data.get("weight", 70)),
        "Height_cm":              float(data.get("height", 170)),
        "Disease_Type":           data.get("disease", "None"),
        "Severity":               data.get("severity", "Mild"),
        "Physical_Activity_Level": data.get("activity", "Moderate"),
        "Weekly_Exercise_Hours":  float(data.get("exercise_hours", 3)),
        "Cholesterol_mg/dL":      float(data.get("cholesterol", 180)),
        "Blood_Pressure_mmHg":    float(data.get("bp", 120)),
        "Glucose_mg/dL":          float(data.get("glucose", 95)),
        "Dietary_Restrictions":   data.get("dietary_restrictions", "None"),
        "Allergies":              data.get("allergies", "None"),
        "Preferred_Cuisine":      data.get("cuisine", "Indian"),
        "Daily_Caloric_Intake":   float(data.get("daily_calories", 2000)),
        "Adherence_to_Diet_Plan": float(data.get("adherence", 70)),
        "Dietary_Nutrient_Imbalance_Score": float(data.get("nutrient_imbalance", 2.5)),
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/recommend", methods=["POST", "OPTIONS"])
def recommend():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        data = request.get_json(force=True)
        patient = _build_patient(data)

        diet_label, confidence, all_probs = predict_diet(patient)
        meal_plan = MEAL_PLANS.get(diet_label, MEAL_PLANS["Balanced"])

        allergies_list = data.get("allergies_list", [])
        if isinstance(allergies_list, str):
            allergies_list = [allergies_list] if allergies_list != "None" else []
        single = data.get("allergies", "None")
        if single and single != "None" and single not in allergies_list:
            allergies_list.append(single)
        allergies_list = [a for a in allergies_list if a and a != "None"]

        allergy_warnings = check_allergies(allergies_list, meal_plan)
        safe_alts = {a: get_safe_alternatives(a) for a in allergies_list if get_safe_alternatives(a)}
        tips = HEALTH_TIPS.get(data.get("disease", "None"), HEALTH_TIPS["None"])

        bmi = patient["Weight_kg"] / ((patient["Height_cm"] / 100) ** 2)
        bmi_category = ("Underweight" if bmi < 18.5 else "Normal Weight" if bmi < 25
                        else "Overweight" if bmi < 30 else "Obese")
        bmi_color = ("#3b82f6" if bmi < 18.5 else "#22c55e" if bmi < 25
                     else "#f59e0b" if bmi < 30 else "#ef4444")

        risk_score = 0
        g, bp, c = patient["Glucose_mg/dL"], patient["Blood_Pressure_mmHg"], patient["Cholesterol_mg/dL"]
        if g > 140: risk_score += 2
        elif g > 110: risk_score += 1
        if bp > 140: risk_score += 2
        elif bp > 120: risk_score += 1
        if c > 240: risk_score += 2
        elif c > 200: risk_score += 1
        if bmi > 30: risk_score += 1

        risk_level = "High" if risk_score >= 4 else "Moderate" if risk_score >= 2 else "Low"
        risk_color = "#ef4444" if risk_level == "High" else "#f59e0b" if risk_level == "Moderate" else "#22c55e"

        # Health score
        health_score = calculate_health_score(patient)
        # Nutrient targets
        nutrient_targets = get_nutrient_targets(diet_label, patient)
        # BMR & TDEE
        bmr = calculate_bmr(patient["Weight_kg"], patient["Height_cm"],
                            patient["Age"], patient["Gender"])
        tdee = calculate_tdee(bmr, patient["Physical_Activity_Level"])
        # Water
        water = calculate_water_intake(patient["Weight_kg"], patient["Physical_Activity_Level"])

        return jsonify({
            "success": True,
            "diet_type": diet_label.replace("_", " "),
            "diet_label": diet_label,
            "confidence": confidence,
            "all_probabilities": all_probs,
            "meal_plan": meal_plan,
            "allergy_warnings": allergy_warnings,
            "safe_alternatives": safe_alts,
            "health_tips": tips,
            "weekly_plan": meal_plan.get("weekly_plan", {}),
            "supplements": meal_plan.get("supplements", []),
            "nutrient_targets": nutrient_targets,
            "health_score": health_score,
            "patient_stats": {
                "bmi": round(bmi, 1), "bmi_category": bmi_category, "bmi_color": bmi_color,
                "risk_level": risk_level, "risk_color": risk_color, "risk_score": risk_score,
                "ideal_weight_range": f"{round(18.5*(patient['Height_cm']/100)**2,1)}–{round(24.9*(patient['Height_cm']/100)**2,1)} kg",
                "bmr": round(bmr), "tdee": round(tdee), "water_L": water
            }
        })
    except Exception as e:
        import traceback
        return jsonify({"success": False, "error": str(e), "trace": traceback.format_exc()}), 500


@app.route("/api/allergy-check", methods=["POST", "OPTIONS"])
def allergy_check():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        data = request.get_json(force=True)
        foods = data.get("foods", [])
        allergies = data.get("allergies", [])
        if isinstance(foods, str):
            foods = [f.strip() for f in foods.split("\n") if f.strip()] or \
                    [f.strip() for f in foods.split(",") if f.strip()]
        if isinstance(allergies, str):
            allergies = [allergies] if allergies != "None" else []

        results = check_food_items(foods, allergies)
        safe = sum(1 for r in results if r["safe"])
        return jsonify({
            "success": True, "results": results,
            "summary": {"total": len(results), "safe": safe, "unsafe": len(results) - safe}
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/health-score", methods=["POST", "OPTIONS"])
def health_score():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        patient = _build_patient(request.get_json(force=True))
        score = calculate_health_score(patient)
        return jsonify({"success": True, **score})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/calories-burned", methods=["POST", "OPTIONS"])
def calories_burned():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        data = request.get_json(force=True)
        weight = float(data.get("weight", 70))
        activity = data.get("activity_type", "Walking (moderate)")
        duration = float(data.get("duration_min", 30))
        burned = calculate_calories_burned(weight, activity, duration)
        return jsonify({"success": True, "calories_burned": burned, "activity": activity, "duration_min": duration})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/water-intake", methods=["POST", "OPTIONS"])
def water_intake():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        data = request.get_json(force=True)
        liters = calculate_water_intake(
            float(data.get("weight", 70)),
            data.get("activity", "Moderate"),
            data.get("climate", "Temperate")
        )
        glasses = round(liters / 0.25)
        return jsonify({"success": True, "liters": liters, "glasses": glasses, "ml": round(liters * 1000)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/nutrient-lookup", methods=["POST", "OPTIONS"])
def nutrient_lookup():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        data = request.get_json(force=True)
        foods = data.get("foods", [])
        results = {}
        for food in foods:
            key = food.lower().strip()
            match = next((v for k, v in FOOD_NUTRITION_DB.items() if k in key or key in k), None)
            results[food] = match if match else None
        return jsonify({"success": True, "results": results})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/model-info", methods=["GET"])
def model_info():
    try:
        saved = load_model()
        report = saved.get("report", {})
        return jsonify({
            "success": True,
            "accuracy": round(saved.get("accuracy", 0) * 100, 2),
            "model_type": "Ensemble (GradientBoosting + RandomForest + ExtraTrees)",
            "dataset_size": 1000,
            "features": len(["CAT×8"] + ["NUM×18"]),
            "diet_classes": saved.get("classes", []),
            "allergens_tracked": list(ALLERGY_FOODS.keys())[:-1],
            "per_class_report": report
        })
    except Exception as e:
        return jsonify({"success": False, "accuracy": 0, "error": str(e)})


@app.route("/api/train", methods=["POST", "OPTIONS"])
def retrain():
    if request.method == "OPTIONS": return jsonify({}), 200
    try:
        acc = train_model()
        return jsonify({"success": True, "accuracy": round(acc * 100, 2)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "version": "2.0", "service": "Life Lens AI"})


if __name__ == "__main__":
    print("Life Lens AI — starting server...")
    try:
        saved = load_model()
        acc = saved.get("accuracy", 0) * 100
        print(f"Ensemble model loaded  accuracy: {acc:.2f}%")
    except Exception as e:
        print(f"Training model on first run... ({e})")
    print("Running at http://localhost:5000")
    app.run(debug=False, port=5000, host="0.0.0.0")
