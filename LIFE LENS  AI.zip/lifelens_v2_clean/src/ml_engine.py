"""
ML engine: ensemble diet prediction, allergy detection, nutrition calculators.
Models: GradientBoosting + RandomForest + ExtraTrees (soft-vote ensemble)
"""

import pandas as pd
import numpy as np
import joblib
import re
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "diet_recommendations.csv"
MODEL_PATH = ROOT / "models" / "lifelens_v2_model.pkl"

TARGET = "Diet_Recommendation"
SEED = 42

CAT_COLS = [
    "Gender", "Severity", "Disease_Type",
    "Disease_Group", "Dietary_Restrictions", "Allergies",
    "Preferred_Cuisine", "Physical_Activity_Level"
]
NUM_COLS = [
    "Age", "Weight_kg", "Height_cm", "BMI",
    "Cholesterol_mg/dL", "Blood_Pressure_mmHg", "Glucose_mg/dL",
    "Weekly_Exercise_Hours", "Daily_Caloric_Intake",
    "Adherence_to_Diet_Plan", "Dietary_Nutrient_Imbalance_Score",
    "Lifestyle_Score", "Risk_Score",
    "Carb_Flag", "Salt_Flag", "Carb_Risk",
    "Age_BMI_Interaction", "BP_Glucose_Risk"
]

# COMPREHENSIVE ALLERGY DATABASE
ALLERGY_FOODS = {
    "Peanuts": [
        "peanut butter", "peanuts", "groundnuts", "satay sauce",
        "mixed nuts", "mole sauce", "peanut oil", "groundnut", "kung pao"
    ],
    "Gluten": [
        "bread", "pasta", "wheat", "flour tortilla", "barley",
        "rye", "couscous", "crackers", "noodles", "whole-grain pita",
        "pita", "wheat flour", "breadcrumbs", "wraps", "chapati",
        "roti", "naan", "croissant", "muffin", "pancake", "waffle"
    ],
    "Lactose": [
        "milk", "cheese", "butter", "cream", "yogurt", "ice cream",
        "whey", "casein", "feta cheese", "greek yogurt", "cheddar cheese",
        "cream cheese", "mozzarella", "parmesan", "brie", "paneer",
        "cottage cheese", "ricotta", "buttermilk", "ghee"
    ],
    "Shellfish": [
        "shrimp", "crab", "lobster", "oysters", "clams",
        "mussels", "scallops", "prawns", "crawfish", "crayfish",
        "squid", "octopus", "abalone"
    ],
    "Eggs": [
        "eggs", "mayonnaise", "meringue", "aioli",
        "egg noodles", "omelette", "hollandaise", "frittata",
        "custard", "quiche", "egg salad"
    ],
    "Tree Nuts": [
        "almond", "walnut", "cashew", "pecan", "pistachio",
        "hazelnut", "macadamia", "almond milk", "almond butter",
        "walnuts", "almond slivers", "brazil nut", "pine nut",
        "coconut", "chestnut"
    ],
    "Soy": [
        "tofu", "soy sauce", "edamame", "tempeh",
        "miso", "soy milk", "soya", "textured vegetable protein",
        "tamari", "natto"
    ],
    "Fish": [
        "salmon", "tuna", "cod", "tilapia", "halibut",
        "anchovy", "sardine", "fish sauce", "salmon fillet",
        "baked salmon", "grilled fish", "mackerel", "trout",
        "haddock", "catfish", "bass", "snapper", "herring"
    ],
    "None": []
}

SAFE_ALTERNATIVES = {
    "Peanuts": {
        "replace_with": "Sunflower seed butter, tahini (sesame paste), or hemp seed butter",
        "avoid": "peanut butter, groundnut oil, satay sauce, mole, mixed nuts",
        "safe_proteins": ["chicken breast", "lentils", "hemp seeds", "pumpkin seeds", "chickpeas"],
        "icon": "🥜", "severity": "High — anaphylaxis risk"
    },
    "Gluten": {
        "replace_with": "Rice, quinoa, certified GF oats, almond flour, cassava flour, millet",
        "avoid": "wheat bread, pasta, barley, rye, most crackers, naan, chapati",
        "safe_proteins": ["rice flour tortillas", "corn tortillas", "quinoa", "buckwheat", "amaranth"],
        "icon": "🌾", "severity": "High — celiac/sensitivity risk"
    },
    "Lactose": {
        "replace_with": "Oat milk, almond milk, coconut yogurt, vegan cheese, cashew cream",
        "avoid": "cow milk, all cheese, butter, cream, whey protein, ghee",
        "safe_proteins": ["lactose-free dairy", "fortified plant milks", "legumes", "tofu"],
        "icon": "🥛", "severity": "Moderate — digestive risk"
    },
    "Shellfish": {
        "replace_with": "White fish (cod, tilapia), chicken breast, firm tofu",
        "avoid": "shrimp, crab, lobster, oysters, clams, mussels, scallops",
        "safe_proteins": ["salmon", "tuna", "chicken", "lentils", "beans", "tofu"],
        "icon": "🦐", "severity": "High — anaphylaxis risk"
    },
    "Eggs": {
        "replace_with": "Flax eggs (1 tbsp ground flax + 3 tbsp water), chia eggs, aquafaba",
        "avoid": "eggs, mayonnaise, meringue, hollandaise, aioli, egg-based sauces",
        "safe_proteins": ["legumes", "tofu", "quinoa", "hemp seeds", "spirulina", "tempeh"],
        "icon": "🥚", "severity": "Moderate–High"
    },
    "Tree Nuts": {
        "replace_with": "Pumpkin seeds, sunflower seeds, hemp seeds, flaxseeds",
        "avoid": "almonds, walnuts, cashews, pecans, pistachios, hazelnuts, macadamia",
        "safe_proteins": ["seeds", "legumes", "poultry", "fish", "pumpkin seeds"],
        "icon": "🌰", "severity": "High — anaphylaxis risk"
    },
    "Soy": {
        "replace_with": "Coconut aminos (soy sauce alt), chickpea miso, hemp tofu",
        "avoid": "tofu, soy sauce, edamame, tempeh, miso, soy milk, tamari",
        "safe_proteins": ["chicken", "fish", "lentils", "eggs", "chickpeas", "hemp"],
        "icon": "🫘", "severity": "Moderate"
    },
    "Fish": {
        "replace_with": "Chicken, turkey, tofu; for omega-3: flaxseed, chia, walnuts",
        "avoid": "all fish species, fish sauce, anchovies, worcestershire sauce",
        "safe_proteins": ["chicken breast", "turkey", "tofu", "legumes", "lean beef"],
        "icon": "🐟", "severity": "High — anaphylaxis risk"
    }
}

# ADVANCED MEAL PLANS — 7-DAY WEEKLY VERSION
MEAL_PLANS = {
    "Balanced": {
        "description": "A well-rounded diet with all macronutrients in healthy proportions for optimal energy and long-term wellness.",
        "calories": "1800–2200 kcal/day",
        "macros": {"Protein": "25%", "Carbs": "50%", "Fat": "25%"},
        "sodium_limit": "2300mg/day",
        "fiber_goal": "28g/day",
        "color": "#3d7a53",
        "meals": {
            "Breakfast": {
                "name": "Oatmeal Power Bowl",
                "ingredients": ["rolled oats", "fresh berries", "Greek yogurt", "honey", "chia seeds", "banana slices"],
                "prep_time": "10 min", "calories": 380,
                "nutrients": {"protein": "18g", "carbs": "58g", "fat": "8g", "fiber": "9g", "sodium": "85mg"}
            },
            "Lunch": {
                "name": "Grilled Chicken Quinoa Salad",
                "ingredients": ["grilled chicken breast", "quinoa", "mixed greens", "cherry tomatoes", "cucumber", "olive oil dressing"],
                "prep_time": "20 min", "calories": 520,
                "nutrients": {"protein": "42g", "carbs": "38g", "fat": "16g", "fiber": "6g", "sodium": "340mg"}
            },
            "Dinner": {
                "name": "Mediterranean Veggie Bowl",
                "ingredients": ["chickpeas", "roasted bell peppers", "hummus", "whole-grain pita", "feta cheese", "kalamata olives"],
                "prep_time": "25 min", "calories": 480,
                "nutrients": {"protein": "22g", "carbs": "62g", "fat": "18g", "fiber": "12g", "sodium": "520mg"}
            },
            "Snack": {
                "name": "Apple & Nut Mix",
                "ingredients": ["apple slices", "almond butter", "walnuts", "cinnamon"],
                "prep_time": "5 min", "calories": 220,
                "nutrients": {"protein": "6g", "carbs": "28g", "fat": "12g", "fiber": "5g", "sodium": "20mg"}
            }
        },
        "weekly_plan": {
            "Monday":    {"B": "Oatmeal with berries & chia", "L": "Grilled chicken quinoa bowl", "D": "Mediterranean veggie bowl", "S": "Apple + almond butter"},
            "Tuesday":   {"B": "Avocado toast on whole grain", "L": "Lentil soup with crusty bread", "D": "Baked cod with sweet potato", "S": "Handful of mixed nuts"},
            "Wednesday": {"B": "Greek yogurt parfait with granola", "L": "Turkey & veggie wrap", "D": "Stir-fry tofu with brown rice", "S": "Hummus with carrot sticks"},
            "Thursday":  {"B": "Banana oat pancakes (no sugar)", "L": "Tuna salad on whole-grain crackers", "D": "Grilled salmon with asparagus", "S": "Mixed fruit salad"},
            "Friday":    {"B": "Veggie omelette with whole-grain toast", "L": "Chickpea & spinach curry", "D": "Chicken stir-fry with quinoa", "S": "Celery + peanut butter"},
            "Saturday":  {"B": "Smoothie bowl (banana, spinach, berries)", "L": "Whole-grain pasta with marinara", "D": "Baked chicken thigh + roasted veggies", "S": "Rice cakes + avocado"},
            "Sunday":    {"B": "Scrambled eggs + whole-grain toast", "L": "Black bean tacos with salsa", "D": "Beef & vegetable soup", "S": "Dark chocolate (70%) + strawberries"}
        },
        "foods_to_avoid": ["processed snacks", "sugary drinks", "excessive alcohol", "fast food", "refined grains"],
        "foods_to_eat": ["lean proteins", "whole grains", "fruits", "vegetables", "healthy fats", "legumes"],
        "supplements": ["Vitamin D3 (1000–2000 IU/day)", "Omega-3 (1g EPA+DHA/day)", "Magnesium glycinate (300mg/day)"]
    },
    "Low_Carb": {
        "description": "Reduced carbohydrate intake to manage blood sugar, support weight management, and reduce systemic inflammation.",
        "calories": "1600–2000 kcal/day",
        "macros": {"Protein": "35%", "Carbs": "15%", "Fat": "50%"},
        "sodium_limit": "2300mg/day",
        "fiber_goal": "25g/day",
        "color": "#c96d3a",
        "meals": {
            "Breakfast": {
                "name": "Spinach & Feta Omelette",
                "ingredients": ["eggs", "baby spinach", "feta cheese", "avocado slices", "olive oil", "fresh herbs"],
                "prep_time": "12 min", "calories": 420,
                "nutrients": {"protein": "28g", "carbs": "8g", "fat": "32g", "fiber": "4g", "sodium": "360mg"}
            },
            "Lunch": {
                "name": "Turkey Lettuce Wraps",
                "ingredients": ["ground turkey", "butter lettuce", "diced tomato", "cucumber", "Greek yogurt sauce", "cumin"],
                "prep_time": "15 min", "calories": 380,
                "nutrients": {"protein": "38g", "carbs": "12g", "fat": "20g", "fiber": "3g", "sodium": "290mg"}
            },
            "Dinner": {
                "name": "Baked Salmon with Broccoli",
                "ingredients": ["salmon fillet", "roasted broccoli", "cauliflower rice", "lemon butter", "garlic", "fresh dill"],
                "prep_time": "30 min", "calories": 520,
                "nutrients": {"protein": "45g", "carbs": "14g", "fat": "32g", "fiber": "6g", "sodium": "310mg"}
            },
            "Snack": {
                "name": "Cheese & Veggie Plate",
                "ingredients": ["cheddar cheese", "celery sticks", "cucumber slices", "cream cheese dip", "bell pepper strips"],
                "prep_time": "5 min", "calories": 180,
                "nutrients": {"protein": "10g", "carbs": "8g", "fat": "14g", "fiber": "2g", "sodium": "220mg"}
            }
        },
        "weekly_plan": {
            "Monday":    {"B": "Bacon & egg muffin cups", "L": "Grilled chicken over greens", "D": "Beef steak + roasted asparagus", "S": "Cheese cubes + olives"},
            "Tuesday":   {"B": "Avocado & smoked salmon on cucumber", "L": "Cauliflower fried rice with shrimp", "D": "Pork tenderloin + sautéed zucchini", "S": "Hard-boiled eggs"},
            "Wednesday": {"B": "Spinach & feta omelette", "L": "Tuna-stuffed avocado", "D": "Lamb kofta + tabbouleh (no bulgur)", "S": "Nuts & seeds mix"},
            "Thursday":  {"B": "Chia pudding with almond milk", "L": "Turkey lettuce wraps", "D": "Baked cod + green beans + almonds", "S": "Celery + cream cheese"},
            "Friday":    {"B": "Keto pancakes (almond flour)", "L": "Caesar salad with chicken (no croutons)", "D": "Salmon with cauliflower mash", "S": "Pepperoni + cheese"},
            "Saturday":  {"B": "Full English (eggs, bacon, mushrooms)", "L": "Bunless burger + coleslaw", "D": "Chicken thighs + roasted Brussels", "S": "Macadamia nuts"},
            "Sunday":    {"B": "Smoked salmon & cream cheese roll-ups", "L": "Egg salad in lettuce cups", "D": "Grilled swordfish + sautéed spinach", "S": "Dark chocolate (90%)"}
        },
        "foods_to_avoid": ["bread", "pasta", "white rice", "sugary drinks", "starchy vegetables", "processed grains", "candy", "fruit juice"],
        "foods_to_eat": ["lean meats", "eggs", "leafy greens", "nuts and seeds", "healthy oils", "low-sugar berries", "avocado", "full-fat dairy"],
        "supplements": ["Electrolytes (sodium, potassium, magnesium)", "MCT Oil (1 tbsp/day)", "B-Complex vitamin"]
    },
    "Low_Sodium": {
        "description": "Restricted sodium intake (under 1,500mg/day) to support blood pressure control and cardiovascular health.",
        "calories": "1800–2100 kcal/day",
        "macros": {"Protein": "25%", "Carbs": "50%", "Fat": "25%"},
        "sodium_limit": "1500mg/day",
        "fiber_goal": "30g/day",
        "color": "#3b6fa0",
        "meals": {
            "Breakfast": {
                "name": "Banana Overnight Oats",
                "ingredients": ["oats (unsalted)", "banana", "almond milk", "cinnamon", "flaxseeds", "blueberries"],
                "prep_time": "5 min + overnight", "calories": 340,
                "nutrients": {"protein": "12g", "carbs": "62g", "fat": "8g", "fiber": "10g", "sodium": "45mg"}
            },
            "Lunch": {
                "name": "Lentil Vegetable Soup",
                "ingredients": ["red lentils", "carrots", "celery", "fresh thyme", "no-salt broth", "sweet potato"],
                "prep_time": "35 min", "calories": 310,
                "nutrients": {"protein": "18g", "carbs": "52g", "fat": "4g", "fiber": "14g", "sodium": "180mg"}
            },
            "Dinner": {
                "name": "Herb-Roasted Chicken",
                "ingredients": ["chicken breast", "sweet potato mash", "steamed green beans", "garlic", "fresh rosemary", "lemon zest"],
                "prep_time": "40 min", "calories": 490,
                "nutrients": {"protein": "45g", "carbs": "38g", "fat": "14g", "fiber": "7g", "sodium": "310mg"}
            },
            "Snack": {
                "name": "Fresh Fruit Salad",
                "ingredients": ["seasonal fruits", "mint leaves", "lemon zest", "pomegranate seeds"],
                "prep_time": "10 min", "calories": 150,
                "nutrients": {"protein": "2g", "carbs": "36g", "fat": "1g", "fiber": "5g", "sodium": "12mg"}
            }
        },
        "weekly_plan": {
            "Monday":    {"B": "Banana overnight oats", "L": "Lentil & vegetable soup", "D": "Herb-roasted chicken + sweet potato", "S": "Fresh fruit salad"},
            "Tuesday":   {"B": "Oatmeal with cinnamon & apple", "L": "Fresh garden salad + quinoa", "D": "Steamed fish + brown rice + greens", "S": "Unsalted rice cakes + avocado"},
            "Wednesday": {"B": "Whole-grain toast + avocado + tomato", "L": "Homemade bean burrito (no salt)", "D": "Turkey meatballs + zucchini noodles", "S": "Unsalted popcorn with herbs"},
            "Thursday":  {"B": "Greek yogurt + fresh mango + flax", "L": "Minestrone (homemade, no-salt)", "D": "Baked tilapia + steamed broccoli", "S": "Apple slices"},
            "Friday":    {"B": "Chia pudding with coconut milk", "L": "Stuffed bell peppers (no salt)", "D": "Chicken stir-fry (coconut aminos)", "S": "Cucumber + hummus (no-salt)"},
            "Saturday":  {"B": "Smoothie: spinach, banana, oat milk", "L": "Black bean tacos (no cheese/salt)", "D": "Grilled salmon + asparagus + lemon", "S": "Watermelon slices"},
            "Sunday":    {"B": "Veggie scramble (no salt, herbs only)", "L": "Pasta with fresh tomato basil sauce", "D": "Slow-cooked chicken & vegetable stew", "S": "Orange + unsalted walnuts"}
        },
        "foods_to_avoid": ["table salt", "canned soups", "processed meats", "pickled foods", "fast food", "soy sauce", "deli meats", "frozen dinners", "cheese (most types)"],
        "foods_to_eat": ["fresh herbs", "lemon and lime juice", "garlic and ginger", "fresh vegetables", "unsalted nuts", "fresh fruits", "potassium-rich foods", "whole grains"],
        "supplements": ["Potassium (consult doctor)", "CoQ10 (100–200mg/day)", "Magnesium (400mg/day)", "Vitamin K2 (100mcg/day)"]
    }
}

HEALTH_TIPS = {
    "Obesity": [
        "Eat slowly — it takes 20 minutes for your brain to register fullness.",
        "Prioritize protein at every meal to reduce hunger hormones by up to 30%.",
        "Replace liquid calories (juice, soda) with water or herbal tea.",
        "Aim for at least 150 minutes of moderate activity per week.",
        "Use smaller plates — visual portion control reduces intake by ~20%.",
        "Plan meals ahead to avoid impulsive high-calorie choices.",
        "Sleep 7–9 hours — poor sleep raises ghrelin (hunger hormone) by 24%.",
        "Track meals for 2 weeks — awareness alone reduces intake significantly."
    ],
    "Diabetes": [
        "Monitor carbohydrate portions — aim for consistent amounts per meal.",
        "Choose low glycemic index foods: legumes, nuts, non-starchy vegetables.",
        "Never skip meals — it causes dangerous blood sugar swings.",
        "Walk 10 minutes after each meal — significantly lowers post-meal glucose.",
        "Apple cider vinegar (1 tbsp before meals) may help lower glucose response.",
        "Eat in this order: fiber → protein → carbs — reduces glucose spike by 37%.",
        "Check blood glucose before and after new foods to learn your personal response.",
        "Stay hydrated — dehydration concentrates blood glucose."
    ],
    "Hypertension": [
        "The DASH diet is clinically proven to lower blood pressure by 8–14 mmHg.",
        "Limit sodium to under 1,500mg daily — read all food labels carefully.",
        "Potassium-rich foods (bananas, sweet potatoes) counteract sodium effects.",
        "Reduce stress — cortisol directly raises blood pressure.",
        "Limit caffeine to 200mg/day — it can spike BP by 5–10 mmHg.",
        "Magnesium-rich foods (spinach, pumpkin seeds) support BP control.",
        "Beetroot juice contains nitrates shown to lower systolic BP by 4–10 mmHg.",
        "Practice slow breathing (6 breaths/min for 15 min) — proven to reduce BP."
    ],
    "Cardiac": [
        "Omega-3 fatty acids from fatty fish or flaxseed actively support heart health.",
        "Limit saturated fats — choose olive oil and avocado over butter.",
        "Soluble fiber from oats and legumes reduces LDL cholesterol by 5–10%.",
        "Regular cardio exercise (150 min/week) strengthens the heart muscle.",
        "Dark chocolate (70%+ cocoa, 1 square/day) contains heart-healthy flavonoids.",
        "CoQ10 from organ meats supports cardiac energy production.",
        "Garlic (1–2 cloves/day) has mild blood-thinning and cholesterol effects.",
        "Avoid trans fats completely — they directly damage arterial walls."
    ],
    "None": [
        "Maintain a colorful plate — different colors provide different phytonutrients.",
        "Stay hydrated: aim for 8 glasses (2L) of water daily.",
        "Include fermented foods (yogurt, kimchi, kefir) for gut microbiome diversity.",
        "Regular health check-ups help catch potential issues before they escalate.",
        "Sleep 7–9 hours nightly — poor sleep is linked to 12+ chronic conditions.",
        "Limit ultra-processed foods — linked to 58 chronic diseases in large studies.",
        "Eat 30 different plant foods per week for maximum microbiome diversity.",
        "Regular sunlight exposure (15–20 min/day) maintains vitamin D levels."
    ]
}

# NUTRIENT REFERENCE VALUES (Daily)
NUTRIENT_RDA = {
    "calories": 2000, "protein_g": 50, "carbs_g": 275, "fat_g": 78,
    "fiber_g": 28, "sodium_mg": 2300, "potassium_mg": 4700,
    "calcium_mg": 1000, "vitamin_c_mg": 90, "iron_mg": 18,
    "vitamin_d_iu": 600, "omega3_g": 1.6
}

FOOD_NUTRITION_DB = {
    "apple": {"calories": 95, "protein": 0.5, "carbs": 25, "fat": 0.3, "fiber": 4.4},
    "banana": {"calories": 105, "protein": 1.3, "carbs": 27, "fat": 0.4, "fiber": 3.1},
    "chicken breast": {"calories": 165, "protein": 31, "carbs": 0, "fat": 3.6, "fiber": 0},
    "salmon": {"calories": 208, "protein": 20, "carbs": 0, "fat": 13, "fiber": 0},
    "brown rice": {"calories": 216, "protein": 5, "carbs": 45, "fat": 1.8, "fiber": 3.5},
    "broccoli": {"calories": 55, "protein": 3.7, "carbs": 11, "fat": 0.6, "fiber": 5.1},
    "eggs": {"calories": 78, "protein": 6, "carbs": 0.6, "fat": 5, "fiber": 0},
    "oats": {"calories": 150, "protein": 5, "carbs": 27, "fat": 2.5, "fiber": 4},
    "quinoa": {"calories": 222, "protein": 8, "carbs": 39, "fat": 3.5, "fiber": 5},
    "greek yogurt": {"calories": 130, "protein": 12, "carbs": 9, "fat": 4, "fiber": 0},
    "avocado": {"calories": 160, "protein": 2, "carbs": 9, "fat": 15, "fiber": 7},
    "spinach": {"calories": 23, "protein": 2.9, "carbs": 3.6, "fat": 0.4, "fiber": 2.2},
    "sweet potato": {"calories": 103, "protein": 2.3, "carbs": 24, "fat": 0.1, "fiber": 3.8},
    "lentils": {"calories": 230, "protein": 18, "carbs": 40, "fat": 0.8, "fiber": 15.6},
    "almonds": {"calories": 164, "protein": 6, "carbs": 6, "fat": 14, "fiber": 3.5},
}

# FEATURE ENGINEERING
def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "BMI" not in df.columns:
        df["BMI"] = df["Weight_kg"] / ((df["Height_cm"] / 100) ** 2)

    df["Disease_Group"] = df["Disease_Type"].map({
        "Cardiac": "Cardio", "Hypertension": "Metabolic",
        "Diabetes": "Metabolic", "None": "Healthy", "Obesity": "Metabolic"
    }).fillna("Healthy")

    lvl = {"Sedentary": 0, "Low": 0, "Moderate": 1, "Active": 2, "High": 2}
    df["Lifestyle_Score"] = (
        0.5 * df["Physical_Activity_Level"].str.strip().map(lvl).fillna(0) +
        0.3 * df["Weekly_Exercise_Hours"] / 10 +
        0.2 * df.get("Adherence_to_Diet_Plan", pd.Series(50, index=df.index)) / 100
    )

    sev = {"Mild": 0, "Moderate": 1, "Severe": 2}
    df["Risk_Score"] = (
        (df["BMI"] > 30).astype(int) +
        (df["Blood_Pressure_mmHg"] > 130).astype(int) +
        (df["Cholesterol_mg/dL"] > 200).astype(int) +
        df["Severity"].map(sev).fillna(0)
    )

    df["Carb_Flag"] = (df["Glucose_mg/dL"] > 120).astype(int)
    df["Salt_Flag"] = (df["Blood_Pressure_mmHg"] > 130).astype(int)
    df["Carb_Risk"] = df["Carb_Flag"] * (df["BMI"] > 28).astype(int)

    # NEW: Advanced interaction features
    df["Age_BMI_Interaction"] = (df["Age"] / 50) * (df["BMI"] / 25)
    df["BP_Glucose_Risk"] = (df["Blood_Pressure_mmHg"] / 120) * (df["Glucose_mg/dL"] / 100)

    if "Daily_Caloric_Intake" not in df.columns:
        df["Daily_Caloric_Intake"] = 2000
    if "Adherence_to_Diet_Plan" not in df.columns:
        df["Adherence_to_Diet_Plan"] = 70
    if "Dietary_Nutrient_Imbalance_Score" not in df.columns:
        df["Dietary_Nutrient_Imbalance_Score"] = 2.5

    for col in CAT_COLS:
        if col in df.columns:
            df[col] = df[col].fillna("None").astype(str)

    return df


# ENSEMBLE MODEL TRAINING
def train_model():
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
    from sklearn.ensemble import (GradientBoostingClassifier,
                                  RandomForestClassifier,
                                  ExtraTreesClassifier,
                                  VotingClassifier)
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.metrics import accuracy_score, classification_report

    print("[ Life Lens AI v2 ] Loading dataset...")
    df = pd.read_csv(DATA_PATH)
    df = add_features(df)

    le = LabelEncoder()
    df["y_enc"] = le.fit_transform(df[TARGET].str.strip())
    class_map = dict(zip(le.transform(le.classes_), le.classes_))

    X = df[CAT_COLS + NUM_COLS]
    y = df["y_enc"]

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED
    )

    pre = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CAT_COLS),
        ("num", StandardScaler(), NUM_COLS)
    ])

    # Three base estimators
    gb = GradientBoostingClassifier(
        n_estimators=500, max_depth=5, learning_rate=0.04,
        subsample=0.85, min_samples_leaf=3, random_state=SEED
    )
    rf = RandomForestClassifier(
        n_estimators=400, max_depth=12, min_samples_leaf=2,
        random_state=SEED, n_jobs=-1
    )
    et = ExtraTreesClassifier(
        n_estimators=400, max_depth=12, min_samples_leaf=2,
        random_state=SEED, n_jobs=-1
    )

    # Soft-voting ensemble
    ensemble = VotingClassifier(
        estimators=[("gb", gb), ("rf", rf), ("et", et)],
        voting="soft", weights=[2, 1, 1]
    )

    model = Pipeline([("pre", pre), ("clf", ensemble)])

    print("[ Life Lens AI v2 ] Training ensemble model...")
    model.fit(X_tr, y_tr)
    acc = accuracy_score(y_te, model.predict(X_te))
    print(f"[ Life Lens AI v2 ] Ensemble Accuracy: {acc:.4f} ({acc*100:.2f}%)")

    report = classification_report(y_te, model.predict(X_te),
                                   target_names=list(le.classes_), output_dict=True)

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({
        "model": model, "map": class_map, "accuracy": acc,
        "classes": list(le.classes_), "report": report
    }, MODEL_PATH)
    print(f"[ Life Lens AI v2 ] Model saved → {MODEL_PATH}")
    return acc


def load_model():
    if not MODEL_PATH.exists():
        train_model()
    return joblib.load(MODEL_PATH)


# PREDICTION
def predict_diet(patient_data: dict):
    saved = load_model()
    model, class_map = saved["model"], saved["map"]

    df = pd.DataFrame([patient_data])
    df = add_features(df)

    for col in CAT_COLS:
        if col not in df.columns:
            df[col] = "None"
    for col in NUM_COLS:
        if col not in df.columns:
            df[col] = 0

    X = df[CAT_COLS + NUM_COLS]
    pred_idx = model.predict(X)[0]
    diet_label = class_map[pred_idx]

    proba = model.predict_proba(X)[0]
    confidence = round(float(max(proba)) * 100, 1)
    all_probs = {class_map[i]: round(float(p) * 100, 1) for i, p in enumerate(proba)}

    return diet_label, confidence, all_probs


# ALLERGY CHECKING
def check_allergies(patient_allergies: list, meal_plan: dict) -> dict:
    flagged = {}
    for meal_name, meal_info in meal_plan["meals"].items():
        conflicts = []
        for allergy in patient_allergies:
            if not allergy or allergy == "None":
                continue
            danger_list = ALLERGY_FOODS.get(allergy, [])
            for ingredient in meal_info["ingredients"]:
                for danger in danger_list:
                    if re.search(r'\b' + re.escape(danger.lower()) + r'\b', ingredient.lower()):
                        conflicts.append({
                            "ingredient": ingredient,
                            "allergy": allergy,
                            "severity": "HIGH",
                            "icon": SAFE_ALTERNATIVES.get(allergy, {}).get("icon", "⚠️")
                        })
        if conflicts:
            flagged[meal_name] = conflicts
    return flagged


def get_safe_alternatives(allergy: str) -> dict:
    return SAFE_ALTERNATIVES.get(allergy, {})


def check_food_items(food_items: list, patient_allergies: list) -> list:
    results = []
    for food in food_items:
        food_lower = food.lower().strip()
        if not food_lower:
            continue
        conflicts = []
        for allergy in patient_allergies:
            if not allergy or allergy == "None":
                continue
            for danger in ALLERGY_FOODS.get(allergy, []):
                if re.search(r'\b' + re.escape(danger.lower()) + r'\b', food_lower):
                    conflicts.append({
                        "allergy": allergy,
                        "matched_ingredient": danger,
                        "icon": SAFE_ALTERNATIVES.get(allergy, {}).get("icon", "⚠️"),
                        "severity": SAFE_ALTERNATIVES.get(allergy, {}).get("severity", "Unknown")
                    })
        results.append({"food": food, "safe": len(conflicts) == 0, "conflicts": conflicts})
    return results


# ADVANCED CALCULATORS
def calculate_bmr(weight_kg, height_cm, age, gender):
    """Mifflin-St Jeor equation."""
    if gender == "Male":
        return 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    else:
        return 10 * weight_kg + 6.25 * height_cm - 5 * age - 161


def calculate_tdee(bmr, activity_level):
    multipliers = {
        "Sedentary": 1.2, "Low": 1.375,
        "Moderate": 1.55, "Active": 1.725, "High": 1.9
    }
    return bmr * multipliers.get(activity_level, 1.55)


def calculate_water_intake(weight_kg, activity_level, climate="Temperate"):
    base = weight_kg * 35  # ml per kg
    activity_add = {"Sedentary": 0, "Low": 200, "Moderate": 400, "Active": 600, "High": 800}
    climate_add = {"Temperate": 0, "Hot": 300, "Very Hot": 600, "Cold": -100}
    total = base + activity_add.get(activity_level, 400) + climate_add.get(climate, 0)
    return round(total / 1000, 1)  # Convert to liters


def calculate_calories_burned(weight_kg, activity_type, duration_min):
    mets = {
        "Walking (moderate)": 3.5, "Running (moderate)": 8.0,
        "Cycling (moderate)": 6.0, "Swimming": 7.0,
        "Yoga": 2.5, "HIIT": 10.0,
        "Weight Training": 5.0, "Dancing": 5.5,
        "Elliptical": 5.5, "Rowing": 7.0
    }
    met = mets.get(activity_type, 4.0)
    return round((met * weight_kg * duration_min) / 60)


def calculate_health_score(patient: dict) -> dict:
    """0–100 composite health score."""
    score = 100
    breakdown = {}

    # BMI contribution (0-25 pts)
    bmi = patient.get("Weight_kg", 70) / ((patient.get("Height_cm", 170) / 100) ** 2)
    if 18.5 <= bmi <= 24.9:
        bmi_score = 25
    elif 25 <= bmi <= 27 or 17 <= bmi < 18.5:
        bmi_score = 18
    elif 27 < bmi <= 30 or 15 <= bmi < 17:
        bmi_score = 10
    else:
        bmi_score = 4
    breakdown["BMI"] = bmi_score

    # Blood pressure (0-20 pts)
    bp = patient.get("Blood_Pressure_mmHg", 120)
    if bp < 120: bp_score = 20
    elif bp < 130: bp_score = 15
    elif bp < 140: bp_score = 8
    else: bp_score = 2
    breakdown["Blood Pressure"] = bp_score

    # Glucose (0-20 pts)
    glu = patient.get("Glucose_mg/dL", 95)
    if glu < 100: glu_score = 20
    elif glu < 110: glu_score = 14
    elif glu < 140: glu_score = 7
    else: glu_score = 2
    breakdown["Blood Glucose"] = glu_score

    # Cholesterol (0-15 pts)
    chol = patient.get("Cholesterol_mg/dL", 180)
    if chol < 170: chol_score = 15
    elif chol < 200: chol_score = 11
    elif chol < 240: chol_score = 5
    else: chol_score = 1
    breakdown["Cholesterol"] = chol_score

    # Activity (0-20 pts)
    lvl_map = {"Sedentary": 3, "Low": 8, "Moderate": 15, "Active": 20, "High": 20}
    act_score = lvl_map.get(patient.get("Physical_Activity_Level", "Moderate"), 10)
    breakdown["Activity Level"] = act_score

    total = sum(breakdown.values())
    grade = "Excellent" if total >= 85 else "Good" if total >= 65 else "Fair" if total >= 45 else "Needs Attention"
    color = "#22c55e" if total >= 85 else "#84cc16" if total >= 65 else "#f59e0b" if total >= 45 else "#ef4444"

    return {"score": total, "grade": grade, "color": color, "breakdown": breakdown, "max": 100}


def get_nutrient_targets(diet_label: str, patient: dict) -> dict:
    """Personalized nutrient targets based on profile."""
    weight = patient.get("Weight_kg", 70)
    plan = MEAL_PLANS.get(diet_label, MEAL_PLANS["Balanced"])

    p_pct = int(plan["macros"]["Protein"].replace("%", "")) / 100
    c_pct = int(plan["macros"]["Carbs"].replace("%", "")) / 100
    f_pct = int(plan["macros"]["Fat"].replace("%", "")) / 100

    cal_range = plan["calories"]
    cal_mid = sum(int(x.split()[0]) for x in cal_range.split("–")) / 2

    return {
        "calories": round(cal_mid),
        "protein_g": round((cal_mid * p_pct) / 4),
        "carbs_g": round((cal_mid * c_pct) / 4),
        "fat_g": round((cal_mid * f_pct) / 9),
        "fiber_g": int(plan["fiber_goal"].replace("g/day", "")),
        "sodium_mg": int(plan["sodium_limit"].replace("mg/day", "").replace(",", "")),
        "water_L": calculate_water_intake(weight, patient.get("Physical_Activity_Level", "Moderate"))
    }
