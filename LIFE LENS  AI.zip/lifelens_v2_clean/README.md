# Life Lens AI

A full-stack ML web app for personalized diet recommendations and health analysis.


## 🚀 Quick Start

```bash
# Install dependencies (Python 3.9+)
pip install flask scikit-learn pandas numpy joblib

# Run the server
cd lifelens_v2
python app.py

# Open browser
http://localhost:5000
```

The ensemble model auto-trains on first launch (~15–20 seconds).

## ✨ What's New in v2

| Feature | v1 | v2 |
|---|---|---|
| ML Algorithm | Single GradientBoosting | **Ensemble (GBM + RF + ET)** |
| Features | 15 | **18 (+ interaction features)** |
| Health Score | ❌ | ✅ **100-point composite score** |
| BMR/TDEE | ❌ | ✅ **Mifflin-St Jeor calculator** |
| Water Intake | ❌ | ✅ **Climate-adjusted recommendation** |
| Calorie Burn | ❌ | ✅ **10 exercise types × MET values** |
| Weekly Plan | ❌ | ✅ **7-day full meal schedule** |
| Nutrient Targets | ❌ | ✅ **Personalized per diet plan** |
| Food Nutrient DB | ❌ | ✅ **15 common foods** |
| Supplements | ❌ | ✅ **Diet-specific recommendations** |
| Allergen Detail | Basic | **Extended (severity + hidden sources)** |
| Per-class Report | ❌ | ✅ **Precision/Recall/F1 dashboard** |
| Sample Patient | ❌ | ✅ **One-click demo load** |
| Print Report | ❌ | ✅ **Browser print support** |

## 📁 Project Structure

```
lifelens_v2/
├── app.py                       ← Flask server (run this)
├── requirements.txt
├── data/
│   └── diet_recommendations.csv  ← 1,000-record dataset
├── models/
│   └── lifelens_v2_model.pkl     ← Trained ensemble (auto-created)
├── src/
│   └── ml_engine.py              ← Full ML + calculators engine
└── templates/
    └── index.html                ← Advanced responsive frontend
```

## 🤖 ML Details

| Property | Value |
|---|---|
| Algorithm | Soft-Voting Ensemble |
| Models | GradientBoosting (w=2) + RandomForest (w=1) + ExtraTrees (w=1) |
| Dataset | 1,000 patient records, 20 columns |
| Features | 18 engineered (8 categorical + 10 numerical) |
| Test Accuracy | 100% |
| Preprocessing | OneHotEncoder + StandardScaler in sklearn Pipeline |
| Split | 80/20 stratified |

## 🌐 API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/` | GET | Frontend |
| `/api/recommend` | POST | Full diet + health analysis |
| `/api/allergy-check` | POST | Allergy food safety scanner |
| `/api/health-score` | POST | 100-point health score |
| `/api/calories-burned` | POST | Exercise calorie calculator |
| `/api/water-intake` | POST | Daily water recommendation |
| `/api/nutrient-lookup` | POST | Food nutrition database lookup |
| `/api/model-info` | GET | Model accuracy + class report |
| `/api/train` | POST | Retrain ensemble model |
| `/api/health` | GET | Server health check |

## ⚕️ Disclaimer
For educational and informational purposes only. Always consult a registered dietitian or physician.
